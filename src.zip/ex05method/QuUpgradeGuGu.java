package ex05method;

public class QuUpgradeGuGu
{

	public static void main(String[] args)
	{
		int dan;
		for( dan=2; dan<=9; dan++) {
			for(int su=1; su<=9; su++) {
				if(su==1) {
					System.out.printf("%d *%d=%d\n ", dan,su,(dan*su));
				}
				for(int su2=2; su2<=9; su2++) {
					
					System.out.printf("%d *%d=%d\n ", dan,a,(dan*a));
				}
			}
			
		}
	}

}
