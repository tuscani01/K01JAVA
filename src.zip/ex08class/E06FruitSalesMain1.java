package ex08class;

public class E06FruitSalesMain1
{

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub

	}

}
